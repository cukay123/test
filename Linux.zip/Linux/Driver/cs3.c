/***************************************************************************************************
 *
 * Description: Linux device driver for CryptoServer Se/CSe/Se2-Series (Model 2,4,5)
 *
 * Author     : Utimaco IS GmbH
 *              Germanusstrasse 4
 *              52080 Aachen
 *              Germany
 *              info@utimaco.com
 *
 * Copyright (C) 2020 Utimaco IS GmbH <www.utimaco.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include <linux/version.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/seq_file.h>
#include <linux/sched.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0))
#include <linux/sched/signal.h>
#endif

#include "cryptoserver.h"
#include "cs2_drv.h"
#include "compat.h"

/******************************************************************************
 *
 * Definitions
 *
 *****************************************************************************/

// PCIe buffer
#define REG_TX_BUFF0            0x0000         // TX buffer 0 address
#define REG_TX_BUFF1            0x1000         // TX buffer 1 address

// PCIe register
#define REG_BASE_OFS            0x10000

#define REG_CS2_IRQ             0x0000         // CS IRQ status register
#define REG_CS2_IRQM            0x0004         // CS IRQ mask register
#define REG_HOST_IRQ            0x0008         // host IRQ status register
#define REG_HOST_IRQM           0x000C         // host IRQ mask register

#define REG_DMA0_ADDR           0x0020         // DMA0 buffer address
#define REG_DMA1_ADDR           0x0024         // DMA1 buffer address

#define REG_TX_LEN0             0x0028         // TX Length register 0
#define REG_TX_LEN1             0x002c         // TX Length register 1
#define REG_RX_LEN0             0x0030         // RX Length register 0
#define REG_RX_LEN1             0x0034         // RX Length register 1

#define REG_RESET               0x0038         // Reset register
#define REG_VERSION             0x003C         // Version register

#define REG_HOST_2_CS_MBX0      0x0040         // Mailbox register PC -> DSP
#define REG_HOST_2_CS_MBX1      0x0044         // Mailbox register PC -> DSP
#define REG_CS_2_HOST_MBX0      0x0048         // Mailbox register DSP -> PC
#define REG_CS_2_HOST_MBX1      0x004C         // Mailbox register DSP -> PC

#define REG_SYSSTAT             0x0050         // System status register
#define REG_SYSSTAT_CHG         0x0054         // System status register changes

// IRQ status bits
#define BIT_IRQ_RX_BF0_FULL     1   // RX buffer 0 full IRQ
#define BIT_IRQ_RX_BF1_FULL     2   // RX buffer 1 full IRQ
#define BIT_IRQ_TX_BF0_ACK      4   // TX buffer 0 ack IRQ
#define BIT_IRQ_TX_BF1_ACK      8   // TX buffer 1 ack IRQ

#define BIT_IRQ_TX_BF0_FULL     1   // TX buffer 0 full IRQ
#define BIT_IRQ_TX_BF1_FULL     2   // TX buffer 1 full IRQ
#define BIT_IRQ_RX_BF0_ACK      4   // RX buffer 0 ack IRQ
#define BIT_IRQ_RX_BF1_ACK      8   // RX buffer 1 ack IRQ

#define BIT_IRQ_MASK            0xF

// transmission buffer
#define PCIE_BLK_SIZE           2048            // sizeof block
#define PCIE_HDR_SIZE           8               // sizeof block header
#define PCIE_DATA_SIZE          (PCIE_BLK_SIZE-PCIE_HDR_SIZE)

// timeouts
#define DEF_TIMEOUT_TX_RX        3*1000               // 3 sec
#define MAX_TIMEOUT_TX_RX       60*1000               // 1 min

#define MAX_TIMEOUT_RESET       60*1000               // 1 min

#define DEF_TIMEOUT_REQUEST     10*60*1000            // 10 min
#define MAX_TIMEOUT_REQUEST     60*60*1000            // 1 hour

//--------------------------------------------------------------------------------
// Device Structure
//--------------------------------------------------------------------------------
struct cs3_device_t
{
  DEVICE_STRUCT_COMMON

  // device specific part
  struct cs_iomem_t       bar0[2];

  volatile unsigned char __iomem *tx_buf0;  // -> 0x0000
  volatile unsigned char __iomem *tx_buf1;  // -> 0x1000
  volatile unsigned char __iomem *reg_base; // -> 0x10000

  long                    timeout;
  unsigned int            crc_flag;
  unsigned char           ch_id;
  void                    *buf;

  // tx
  wait_queue_head_t       tx_queue;
  volatile int            tx_state;
  int                     tx_reset;
  int                     tx_error;
  volatile char           tx_ack[2];
  unsigned int            tx_count;

  // rx
  struct cs_dmabuf_t      rx_buf0;
  struct cs_dmabuf_t      rx_buf1;

  wait_queue_head_t       rx_queue;
  volatile int            rx_state;
  int                     rx_reset;
  int                     rx_error;
  volatile char           rx_full[2];
  unsigned int            rx_count;
  unsigned int            rx_crc_err;

  wait_queue_head_t       spm_queue;
  volatile int            spm_state;
  volatile int            rcvd_cmds_rdy;

  unsigned int            req_len;

  struct semaphore        sema;

  struct tasklet_struct   *task;
  unsigned int            task_irq;
  spinlock_t              task_lock;

  // statistics
  struct
  {
    unsigned int irq_count[16];
  }
  stats;
};


// RX / TX states
#define STATE_IDLE        0
#define STATE_WAIT        1
#define STATE_READ        2
#define STATE_WRITE       3
#define STATE_RESET       4

static const char *StateText[] =
{
  "idle",
  "read",
  "write",
  "wait",
  "reset",
  "?",
  "??",
  "???"
};

/******************************************************************************
 *
 * Globals
 *
 *****************************************************************************/
static unsigned int   DeviceCount = 0;

static unsigned short Crc_tab1[256];
static unsigned short Crc_tab2[256];
static unsigned short Crc_tab3[256];
static unsigned short Crc_tab4[256];

/******************************************************************************
 *
 * cs3_crc16_slow
 *
 ******************************************************************************/
static unsigned int cs3_crc16_slow(unsigned int crc, unsigned char *data, unsigned int len)
{
  unsigned int dd;

  while (len-- != 0)
  {
    dd = (crc >> 8) & 0xff;
    crc = (crc << 8) | *data++;
    dd ^= dd >> 4;
    crc ^= (dd << 12) ^ (dd << 5) ^ dd;
  }

  return crc;
}

/******************************************************************************
 *
 * cs3_crc16
 *
 ******************************************************************************/
static unsigned int cs3_crc16(unsigned int crc, unsigned char *data, unsigned int len)
{
  while (len >= 4)
  {
    len -= 4;
    crc = Crc_tab4[crc >> 8]
        ^ Crc_tab3[crc & 0xff]
        ^ Crc_tab2[data[0]]
        ^ Crc_tab1[data[1]]
        ^ ((data[2] << 8) | data[3]);
    data += 4;
  }

  if (len)
    crc = cs3_crc16_slow(crc, data, len);

  return crc & 0xffff;
}

/******************************************************************************
 *
 * cs3_io_map
 *
 *****************************************************************************/
#define WHERE "cs3_io_map"
static int cs3_io_map(struct cs3_device_t *dp)
{
  struct pci_dev    *pci_dev = dp->pci_dev;
  unsigned long     addr;
  unsigned long     size;
  struct cs_iomem_t *bar;
  int i;

  if (  (addr = pci_resource_start(pci_dev, 0)) == 0
     || (size = pci_resource_len  (pci_dev, 0)) == 0
     )
  {
    log_error(WHERE": no resource BAR0\n");
    return -ENODEV;
  }

  log_trace(WHERE": BAR0: phys_addr: %lx, size: 0x%lx\n", addr, size);

  // tx buffer 0/1
  bar = dp->bar0;
  bar->phys_addr = addr;
  bar->size = 0x2000;

  if ((bar->base_ptr = ioremap_wc(bar->phys_addr, bar->size)) == NULL)
  {
    log_error(WHERE": can't remap io memory for BAR0 tx buffers\n");
    return -ENODEV;
  }

  dp->tx_buf0 = bar->base_ptr + REG_TX_BUFF0;
  dp->tx_buf1 = bar->base_ptr + REG_TX_BUFF1;

  // registers
  bar++;
  bar->phys_addr = addr + REG_BASE_OFS;
  bar->size = 0x1000;

  if ((bar->base_ptr = ioremap(bar->phys_addr, bar->size)) == NULL)
  {
    log_error(WHERE": can't remap io memory for BAR0 registers\n");
    return -ENODEV;
  }

  dp->reg_base = bar->base_ptr;

  for (i=0; i<2; i++)
  {
    bar = dp->bar0 + i;

    log_trace(WHERE": bar0[%d]: phys.: %08X:%08X -> virt.: %p, size = 0x%08lX\n", i, bar->phys_addr_hi,
                                                                                  bar->phys_addr_lo,
                                                                                  bar->base_ptr,
                                                                                  bar->size);
  }
  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_io_unmap
 *
 *****************************************************************************/
static int cs3_io_unmap(struct cs3_device_t *dp)
{
  struct cs_iomem_t *bar;
  int i;

  for (i=0; i<2; i++)
  {
    bar = dp->bar0 + i;

    iounmap(bar->base_ptr);
    bar->base_ptr = NULL;
  }

  dp->reg_base = NULL;
  dp->tx_buf0  = NULL;
  dp->tx_buf1  = NULL;

  return 0;
}

/******************************************************************************
 *
 * cs3_dma_alloc
 *
 *****************************************************************************/
#define WHERE "cs3_dma_alloc"
static int cs3_dma_alloc(struct cs3_device_t *dp, unsigned int size, struct cs_dmabuf_t *buf)
{
  buf->base_ptr = pci_alloc_consistent(dp->pci_dev, size, &buf->phys_addr);

  if (buf->base_ptr == NULL)
  {
    log_error(WHERE": dma_alloc_coherent failed\n");
    return -ENOMEM;
  }

  buf->size = size;

  log_debug(WHERE": Virtual Address = %p, Physical Address = %08X:%08X, size = %d\n",
                    buf->base_ptr,
                    buf->phys_addr_hi,
                    buf->phys_addr_lo,
                    buf->size);
  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_dma_free
 *
 *****************************************************************************/
static void cs3_dma_free(struct cs3_device_t *dp, struct cs_dmabuf_t *buf)
{
  if (buf->base_ptr == NULL) return;

  pci_free_consistent(dp->pci_dev, buf->size, buf->base_ptr, buf->phys_addr);

  buf->base_ptr = NULL;
}

/******************************************************************************
 *
 * cs3_dma_clear
 *
 *****************************************************************************/
static inline void cs3_dma_clear(struct cs_dmabuf_t *buf)
{
  memset(buf->base_ptr, 0, buf->size);
}

/******************************************************************************
 *
 * cs3_spm_error
 *
 ******************************************************************************/
static int cs3_spm_error(const char *where, struct cs3_device_t *dp)
{
  if (dp->spm_state == 0x5306)
  {
    log_error("%s: high temperature detected\n", where);
    return -ECS2TEMPALARM;
  }

  switch (dp->spm_state >> 8)
  {
    case 0x50:
      log_error("%s: CryptoServer panicked: %04x\n", where, dp->spm_state);
      return -ECS2PANIC;

    case 0x53:
      log_error("%s: CryptoServer is down: %04x\n", where, dp->spm_state);
      return -ECS2DOWN;

    default:
      log_error("%s: operation was interrupted by reset\n", where);
      return -ECS2RESET;
  }
}

/******************************************************************************
 *
 * cs3_legacy_isr
 *
 ******************************************************************************/
#define WHERE "cs3_legacy_isr"
static irqreturn_t cs3_legacy_isr(int irq, struct cs3_device_t *dp)
{
  irqreturn_t ret;
  u32         status;

  status = ~readl(dp->reg_base + REG_HOST_IRQ) & BIT_IRQ_MASK;

  if (status & BIT_IRQ_TX_BF0_ACK)
  {
    writel(BIT_IRQ_TX_BF0_ACK, dp->reg_base + REG_HOST_IRQ);
    dp->task_irq |= BIT_IRQ_TX_BF0_ACK;
  }

  if (status & BIT_IRQ_TX_BF1_ACK)
  {
    writel(BIT_IRQ_TX_BF1_ACK, dp->reg_base + REG_HOST_IRQ);
    dp->task_irq |= BIT_IRQ_TX_BF1_ACK;
  }

  if (status & BIT_IRQ_RX_BF0_FULL)
  {
    writel(BIT_IRQ_RX_BF0_FULL, dp->reg_base + REG_HOST_IRQ);
    dp->task_irq |= BIT_IRQ_RX_BF0_FULL;
  }

  if (status & BIT_IRQ_RX_BF1_FULL)
  {
    writel(BIT_IRQ_RX_BF1_FULL, dp->reg_base + REG_HOST_IRQ);
    dp->task_irq |= BIT_IRQ_RX_BF1_FULL;
  }

  if (status != 0)
  {
    readl(dp->reg_base + REG_VERSION);

    tasklet_schedule(dp->task);

    ret = IRQ_HANDLED;
  }
  else
  {
    ret = IRQ_NONE;
  }

  dp->stats.irq_count[status]++;
  return ret;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_msi_isr
 *
 ******************************************************************************/
#define WHERE "cs3_msi_isr"
static irqreturn_t cs3_msi_isr(int irq, struct cs3_device_t *dp)
{
  irqreturn_t ret;
  u32         status;

  status = ~readl(dp->reg_base + REG_HOST_IRQ) & BIT_IRQ_MASK;

  if (status != 0)
  {
    writel(status, dp->reg_base + REG_HOST_IRQ);
    readl(dp->reg_base + REG_VERSION);

    dp->task_irq |= status;
    tasklet_schedule(dp->task);

    ret = IRQ_HANDLED;
  }
  else
  {
    ret = IRQ_NONE;
  }

  dp->stats.irq_count[status]++;
  return ret;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_irq_request
 *
 *****************************************************************************/
#define WHERE "cs3_irq_request"
static int cs3_irq_request(struct cs3_device_t *dp)
{
  int err = 0;
  struct pci_dev *pci_dev = dp->pci_dev;
  unsigned int irq;
  irqreturn_t (*p_isr)(int irq, struct cs3_device_t*);

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,8,0))
  // new style
  if (  MsiMode
     && pci_alloc_irq_vectors(pci_dev, 1, 1, PCI_IRQ_MSI) == 1
     )
  {
    p_isr = cs3_msi_isr;
  }
  else if (pci_alloc_irq_vectors(pci_dev, 1, 1, PCI_IRQ_LEGACY) == 1)
  {
    p_isr = cs3_legacy_isr;
  }
  else
  {
    log_error(WHERE": can't allocate any interrupt\n");
    CLEANUP(-ENOMEM);
  }

  irq = pci_irq_vector(pci_dev, 0);
#else
  // old style
  if (  MsiMode
     && pci_enable_msi(pci_dev) == 0
     )
  {
    p_isr = cs3_msi_isr;
  }
  else
  {
    p_isr = cs3_legacy_isr;
  }

  irq = pci_dev->irq;
#endif

  dp->irq_mode = (p_isr == cs3_msi_isr);

  log_info(WHERE": using %s irq mode\n", dp->irq_mode ? "MSI" : "legacy");

  if ((err = request_irq(irq, (irqreturn_t (*)(int,void*))p_isr, IRQF_SHARED, "cs3", dp)) != 0)
  {
    log_error(WHERE": request_irq(%d) returned: %d\n", irq, err);
    goto cleanup;
  }

  log_trace(WHERE": successfully initialized irq: %d\n", irq);

cleanup:
  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_irq_free
 *
 *****************************************************************************/
#define WHERE "cs3_irq_free"
static void cs3_irq_free(struct cs3_device_t *dp)
{
  struct pci_dev *pci_dev = dp->pci_dev;
  unsigned int irq;

  if (pci_dev == NULL) return;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,8,0))
  irq = pci_irq_vector(pci_dev, 0);
  free_irq(irq, dp);
  pci_free_irq_vectors(pci_dev);
#else
  irq = pci_dev->irq;
  free_irq(irq, dp);
  pci_disable_msi(pci_dev);
#endif
}
#undef WHERE

/******************************************************************************
 *
 * cs3_irq_enable
 *
 ******************************************************************************/
static void cs3_irq_enable(struct cs3_device_t *dp)
{
  writel( BIT_IRQ_TX_BF0_ACK
        | BIT_IRQ_TX_BF1_ACK
        | BIT_IRQ_RX_BF0_FULL
        | BIT_IRQ_RX_BF1_FULL, dp->reg_base + REG_HOST_IRQM);
}

/******************************************************************************
 *
 * cs3_irq_disable
 *
 ******************************************************************************/
static void cs3_irq_disable(struct cs3_device_t *dp)
{
  writel(0, dp->reg_base + REG_HOST_IRQM);
}

/******************************************************************************
 *
 * cs3_irq_clear
 *
 ******************************************************************************/
static inline void cs3_irq_clear(struct cs3_device_t *dp)
{
  writel( BIT_IRQ_TX_BF0_ACK
        | BIT_IRQ_TX_BF1_ACK
        | BIT_IRQ_RX_BF0_FULL
        | BIT_IRQ_RX_BF1_FULL, dp->reg_base + REG_HOST_IRQ);
}

/******************************************************************************
 *
 * cs3_wait_for_spm
 *
 ******************************************************************************/
#define WHERE "cs3_wait_for_spm"
static inline int cs3_wait_for_spm(struct cs3_device_t *dp, long timeout)
{
  int err;
  wait_queue_head_t *queue = &dp->spm_queue;
  wait_queue_entry_t waiter;

  init_waitqueue_entry(&waiter, current);
  add_wait_queue(queue, &waiter);

  for (;;)
  {
    set_current_state(TASK_INTERRUPTIBLE);

    if (dp->spm_state != 0)
    {
      err = 0;
      break;
    }

    if (signal_pending(current))
    {
      err = -ERESTARTSYS;
      break;
    }

    if (timeout <= 0)
    {
      err = -ECS2TIMEOUT;
      break;
    }

    timeout = schedule_timeout(timeout);
  }

  set_current_state(TASK_RUNNING);
  remove_wait_queue(queue, &waiter);

  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_wait_for_rx_full
 *
 *****************************************************************************/
#define WHERE "cs3_wait_for_rx_full"
static inline int cs3_wait_for_rx_full(struct cs3_device_t *dp, int idx, long timeout, int ignsig)
{
  int err;
  wait_queue_head_t *queue = &dp->rx_queue;
  wait_queue_entry_t waiter;

  init_waitqueue_entry(&waiter, current);
  add_wait_queue(queue, &waiter);

  for (;;)
  {
    set_current_state(TASK_INTERRUPTIBLE);

    if (dp->rx_reset)
    {
      err = cs3_spm_error(WHERE, dp);
      break;
    }

    /* CMDS ready */
    if (dp->rcvd_cmds_rdy)
    {
      err = cs3_spm_error(WHERE, dp);
      dp->rcvd_cmds_rdy = 0;
      break;
    }

    if (dp->rx_full[idx] != 0)
    {
      err = 0;
      break;
    }

    if (ignsig == 0 && signal_pending(current))
    {
      err = -ERESTARTSYS;
      break;
    }

    if (timeout <= 0)
    {
      err = -ECS2TIMEOUT;
      break;
    }

    timeout = schedule_timeout(timeout);
  }

  set_current_state(TASK_RUNNING);
  remove_wait_queue(queue, &waiter);

  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_wait_for_tx_ack
 *
 *****************************************************************************/
#define WHERE "cs3_wait_for_tx_ack"
static inline int cs3_wait_for_tx_ack(struct cs3_device_t *dp, int idx, long timeout)
{
  int err;
  wait_queue_head_t *queue = &dp->tx_queue;
  wait_queue_entry_t waiter;

  init_waitqueue_entry(&waiter, current);
  add_wait_queue(queue, &waiter);

  for (;;)
  {
    set_current_state(TASK_INTERRUPTIBLE);

    if (dp->tx_reset)
    {
      err = cs3_spm_error(WHERE, dp);
      break;
    }

    /* CMDS ready */
    if (dp->rcvd_cmds_rdy)
    {
      err = cs3_spm_error(WHERE, dp);
      dp->rcvd_cmds_rdy = 0;
      break;
    }

    if (dp->tx_ack[idx] != 0)
    {
      err = 0;
      break;
    }

    if (timeout <= 0)
    {
      err = -ECS2TIMEOUT;
      break;
    }

    timeout = schedule_timeout(timeout);
  }

  set_current_state(TASK_RUNNING);
  remove_wait_queue(queue, &waiter);

  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_task_proc
 *
 *****************************************************************************/
#define WHERE "cs3_task_proc"
static void cs3_task_proc(struct cs3_device_t *dp)
{
  unsigned long flags;

  spin_lock_irqsave(&dp->task_lock, flags);

  if (dp->task_irq & BIT_IRQ_TX_BF0_ACK)
  {
    dp->task_irq &= ~BIT_IRQ_TX_BF0_ACK;

    dp->tx_ack[0] = 1;
    wake_up_interruptible(&dp->tx_queue);
  }

  if (dp->task_irq & BIT_IRQ_TX_BF1_ACK)
  {
    dp->task_irq &= ~BIT_IRQ_TX_BF1_ACK;

    dp->tx_ack[1] = 1;
    wake_up_interruptible(&dp->tx_queue);
  }

  if (dp->task_irq & BIT_IRQ_RX_BF0_FULL)
  {
    dp->task_irq &= ~BIT_IRQ_RX_BF0_FULL;

    dp->rx_full[0] = 1;
    wake_up_interruptible(&dp->rx_queue);
  }

  if (dp->task_irq & BIT_IRQ_RX_BF1_FULL)
  {
    unsigned int spm;

    dp->task_irq &= ~BIT_IRQ_RX_BF1_FULL;

    spm = readl(dp->reg_base + REG_RX_LEN1) >> 16;

    if (spm != 0)
    {
      // spontaneous message
      char *txt;

      dp->spm_state = spm;

      switch (spm)
      {
        case 0x4000: txt = "[BL ready]"; break;
        case 0x8000: txt = "[CMDS ready]"; break;
        case 0x5001: txt = "[BL CRC error]"; break;
        case 0x5002: txt = "[BL SDRAM error]"; break;
        case 0x500B: txt = "[PCI interface closed]"; break;
        case 0x500C: txt = "[memory corruption]"; break;
        case 0x5306: txt = "[high temperature]"; break;
        case 0x530A: txt = "[alarm was reset]"; break;
        case 0x530E: txt = "[CryptoServer was cleared]"; break;
        case 0x5344: txt = "[CryptoServer was shut down]"; break;
        default:     txt = "[?]"; break;
      }

      log_info(WHERE": spontaneous message from [%s] received: %04x %s\n", dp->device_name, spm, txt);

      if ((spm & 0x1000) == 0)
      {
        // ready message
        dp->tx_reset = 0;
        dp->rx_reset = 0;
        if (spm == 0x8000)
        {
          /* commands that were sent between BL ready and CMDS ready need to be unblocked */
          dp->rcvd_cmds_rdy = 1;
          wake_up_interruptible(&dp->rx_queue);
          wake_up_interruptible(&dp->tx_queue);
        }
      }
      else
      {
        // 'panic' message
        dp->tx_reset = 1;
        dp->rx_reset = 1;

        wake_up_interruptible(&dp->rx_queue);
        wake_up_interruptible(&dp->tx_queue);
      }

      wake_up_interruptible(&dp->spm_queue);
    }
    else
    {
      dp->rx_full[1] = 1;
      wake_up_interruptible(&dp->rx_queue);
    }
  }

  spin_unlock_irqrestore(&dp->task_lock, flags);
}
#undef WHERE

/******************************************************************************
 *
 * cs3_open
 *
 *****************************************************************************/
static int cs3_open(struct cs_session_t *session)
{
  return 0;
}

/******************************************************************************
 *
 * cs3_close
 *
 *****************************************************************************/
#define WHERE "cs3_close"
static int cs3_close(struct cs_session_t *session)
{
  struct cs3_device_t *dp = (struct cs3_device_t*)session->dp;

  if (session->has_sema)
  {
    session->has_sema = 0;
    up(&dp->sema);
    log_info(WHERE": semaphore unlocked [%d]\n", dp->sema.count);
  }

  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_reset
 *
 ******************************************************************************/
static int cs3_reset(struct cs3_device_t *dp)
{
  dp->rx_reset = 1;
  dp->tx_reset = 1;

  wake_up_interruptible(&dp->rx_queue);
  wake_up_interruptible(&dp->tx_queue);

  dp->spm_state = 0;

  writel(0,                        dp->reg_base + REG_RESET);
  writel(0,                        dp->reg_base + REG_HOST_2_CS_MBX0);
  writel(0,                        dp->reg_base + REG_HOST_2_CS_MBX1);
  writel(0,                        dp->reg_base + REG_TX_LEN0);
  writel(0,                        dp->reg_base + REG_TX_LEN1);
  writel(dp->rx_buf0.phys_addr_lo, dp->reg_base + REG_DMA0_ADDR);
  writel(dp->rx_buf1.phys_addr_lo, dp->reg_base + REG_DMA1_ADDR);

  udelay(10);

  readl(dp->reg_base + REG_VERSION);     // flush PCI

  cs3_irq_enable(dp);

  dp->tx_state = STATE_RESET;
  dp->rx_state = STATE_RESET;

  memset(&dp->stats, 0, sizeof(dp->stats));
  return 0;
}

/******************************************************************************
 *
 * cs3_shutdown
 *
 *****************************************************************************/
#define WHERE "cs3_shutdown"
static int cs3_shutdown(struct cs3_device_t *dp, long timeout)
{
  int err;
  unsigned int mode = ShutdownMode & 3;

  if (dp->model < 4) return -EINVAL;

  log_trace(WHERE": mode    = %d\n", mode);
  log_trace(WHERE": timeout = %ld\n", timeout);

  dp->rx_reset = 1;
  dp->tx_reset = 1;

  wake_up_interruptible(&dp->rx_queue);
  wake_up_interruptible(&dp->tx_queue);

  dp->spm_state = 0;

  // send SPM
  writel(0x53440000 + mode, dp->reg_base + REG_TX_LEN1);
  writel(~BIT_IRQ_TX_BF1_FULL, dp->reg_base + REG_CS2_IRQ);

  if (timeout == 0) return 0;

  // wait on response SPM
  if ((err = cs3_wait_for_spm(dp, timeout)) != 0)
  {
    log_error(WHERE": cs3_wait_for_spm returned: %d\n", err);
    return err;
  }

  if (dp->spm_state != 0x5344)
  {
    log_error(WHERE": CryptoServer didn't respond to shutdown signal, spm:%08x\n", dp->spm_state);
    return -ENOMSG;
  }

  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_info
 *
 *****************************************************************************/
static int cs3_info(struct cs3_device_t *dp, char *info, int max)
{
  char *p = info;
  int len = 0;

  unsigned int  version;
  const char    *spm_state;
  unsigned int  *cnt;

  if (dp == NULL) return -ENODEV;

  len += snprintf(p+len, max-len, "drv vers.  %s\n", DriverVersionString);

  version = readl(dp->reg_base + REG_VERSION);
  len += snprintf(p+len, max-len, "fpga vers. %d.%d.%d.%d\n", version >> 24, (version >> 16) & 0xff, (version >> 8) & 0xff, version & 0xff);

  len += snprintf(p+len, max-len, "slot       %-16.16s\n", dp->slot);
  len += snprintf(p+len, max-len, "model      %s\n", ModelTxt[dp->model&7]);

  len += snprintf(p+len, max-len, "crc_flag   %d\n", dp->crc_flag);
  len += snprintf(p+len, max-len, "irq mode   %s\n", dp->irq_mode ? "MSI" : "legacy");

  len += snprintf(p+len, max-len, "sema.count %d\n", dp->sema.count);

  switch (dp->spm_state >> 8)
  {
    case 0x50: spm_state = "[panic]"; break;
    case 0x53: spm_state = "[shutdown]";  break;
    default:   spm_state = ""; break;
  }

  len += snprintf(p+len, max-len, "spm        %04x %s\n", dp->spm_state, spm_state);

  len += snprintf(p+len, max-len, "tx_state   %s\n", StateText[dp->tx_state&7]);
  len += snprintf(p+len, max-len, "rx_state   %s\n", StateText[dp->rx_state&7]);

  len += snprintf(p+len, max-len, "tx_count   %8u\n",     dp->tx_count);
  len += snprintf(p+len, max-len, "rx_count   %8u %8u\n", dp->rx_count, dp->rx_crc_err);

  len += snprintf(p+len, max-len, "tx_len     %08x %08x\n", readl(dp->reg_base + REG_TX_LEN0), readl(dp->reg_base + REG_TX_LEN1));
  len += snprintf(p+len, max-len, "rx_len     %08x %08x\n", readl(dp->reg_base + REG_RX_LEN0), readl(dp->reg_base + REG_RX_LEN1));

  len += snprintf(p+len, max-len, "irq        %4x%4x %4x%4x\n", readl(dp->reg_base + REG_CS2_IRQ  ) & 0xf,
                                                                readl(dp->reg_base + REG_CS2_IRQM ) & 0xf,
                                                                readl(dp->reg_base + REG_HOST_IRQ ) & 0xf,
                                                                readl(dp->reg_base + REG_HOST_IRQM) & 0xf);
  cnt = dp->stats.irq_count;
  len += snprintf(p+len, max-len, "irq_cnt[0] %8d\n", cnt[0]);
  len += snprintf(p+len, max-len, "       [1] %8d %8d %8d %8d\n", cnt[1], cnt[2], cnt[4], cnt[8]);
  len += snprintf(p+len, max-len, "       [2] %8d %8d %8d %8d %8d %8d\n", cnt[3], cnt[5], cnt[6], cnt[9],cnt[10], cnt[12]);
  len += snprintf(p+len, max-len, "       [3] %8d %8d %8d\n", cnt[7], cnt[13], cnt[14]);
  len += snprintf(p+len, max-len, "       [4] %8d\n", cnt[15]);

  if (dp->model >= 5)
  {
    len += snprintf(p+len, max-len, "mbx pc2dsp %08x %08x\n", readl(dp->reg_base + REG_HOST_2_CS_MBX0),
                                                              readl(dp->reg_base + REG_HOST_2_CS_MBX1));

    len += snprintf(p+len, max-len, "mbx dsp2pc %08x %08x\n", readl(dp->reg_base + REG_CS_2_HOST_MBX0),
                                                              readl(dp->reg_base + REG_CS_2_HOST_MBX1));

    len += snprintf(p+len, max-len, "sysstat    %08x %08x\n", readl(dp->reg_base + REG_SYSSTAT),
                                                              readl(dp->reg_base + REG_SYSSTAT_CHG));
  }

  // p[len++] = 0;

  return len;
}

/******************************************************************************
 *
 * cs3_ioctl
 *
 *****************************************************************************/
static int cs3_ioctl(struct cs_session_t *session, unsigned int cmd, unsigned long arg)
{
  int err = 0;
  struct cs3_device_t *dp = (struct cs3_device_t*)session->dp;

  switch (cmd)
  {
    //--------------------------------------------------------------------------------
    case CS2IOC_SHUTDOWN:
    //--------------------------------------------------------------------------------
      return cs3_shutdown(dp, 0);

    //-------------------------------------------------------------------------
    case CS2IOC_HRESET:
    //-------------------------------------------------------------------------
      cs3_shutdown(dp, 500);
      cs3_reset(dp);
      return 0;

    //--------------------------------------------------------------------------------
    case CS2IOC_GETHWTYPE:
    //--------------------------------------------------------------------------------
      if (put_user(dp->model, (int*)arg) != 0) return -EFAULT;
      return 0;

    //--------------------------------------------------------------------------------
    case CS2IOC_WAIT_RDY:
    //--------------------------------------------------------------------------------
    #define WHERE "cs3_ioctl [CS2IOC_WAIT_RDY]"
    {
      struct cs2_waitrdy *p_wait = (struct cs2_waitrdy *)arg;
      long timeout;

      if (get_user(timeout, &p_wait->timeout)) return -EFAULT;

      if (timeout < 0) timeout = MAX_TIMEOUT_RESET;

      timeout = msecs_to_jiffies(timeout);

      if (dp->spm_state == 0)
      {
        if ((err = cs3_wait_for_spm(dp, timeout)) != 0)
        {
          log_error(WHERE": cs3_wait_for_spm returned: %d\n", err);
          return err;
        }
      }

      if (dp->rx_reset) return cs3_spm_error(WHERE, dp);

      if (put_user(dp->spm_state, &p_wait->state) != 0) return -EFAULT;

      dp->spm_state = 0;
      return 0;
    }
    #undef WHERE

    //--------------------------------------------------------------------------------
    case CS2IOC_GETREQ:
    //--------------------------------------------------------------------------------
    #define WHERE "cs3_ioctl [CS2IOC_GETREQ]"
    {
      struct cs2_getreq *p_req = (struct cs2_getreq *)arg;
      long timeout;

      if (get_user(timeout, &p_req->timeout)) return -EFAULT;

      for (;;)
      {
        if (dp->rx_full[0] != 0)
        {
          // no wait
          unsigned char *p_hdr;
          unsigned int  len;

          if ((len = readl(dp->reg_base + REG_RX_LEN0)) < PCIE_HDR_SIZE)
          {
            log_error(WHERE": RX block dropped: invalid header size: %d\n", len);
            dp->rx_full[0] = 0;
            continue;
          }

          p_hdr = dp->rx_buf0.base_ptr;

          if (  p_hdr[1] != dp->ch_id
             || p_hdr[2] != 0
             )
          {
            log_error(WHERE": RX block dropped: invalid channel id: %04x, expected: %04x\n", ((p_hdr[1] << 8) + p_hdr[2]),
                                                                                             (dp->ch_id << 8));

            dp->rx_full[0] = 0;
            continue;
          }

          dp->req_len = (p_hdr[5] << 16) + (p_hdr[6] << 8) +  p_hdr[7];
          break;
        }

        if (timeout == 0) return -EAGAIN;

        dp->rx_state = STATE_WAIT;

        if (dp->rx_full[0] == 0)
        {
          if (  timeout < 0
             || timeout > MAX_TIMEOUT_REQUEST
             )
            timeout = DEF_TIMEOUT_REQUEST;

          err = cs3_wait_for_rx_full(dp, 0, msecs_to_jiffies(timeout), 0);
        }

        dp->rx_state = STATE_IDLE;

        if (err != 0) return err;
      }

      // copy data to user buffer
      if (  put_user(dp->req_len, &p_req->req_size) != 0
         || put_user(dp->ch_id, &p_req->req_id) != 0
         )
        return -EFAULT;

      log_debug(WHERE": req_size = %d", p_req->req_size);
      break;
    }
    #undef WHERE

    //--------------------------------------------------------------------------------
    case CS2IOC_CANCEL:
    //--------------------------------------------------------------------------------
      return 0;

     //--------------------------------------------------------------------------------
    case CS2IOC_GETINFO:
    //--------------------------------------------------------------------------------
    {
      struct cs2_info *p_info = (struct cs2_info *)arg;
      char            *buf = NULL;
      int             len;

      if ((buf = kzalloc(PAGE_SIZE, GFP_KERNEL)) == NULL) return -ENOMEM;

      if ((len = cs3_info(dp, buf, PAGE_SIZE)) < 0)
      {
        err = len;
      }
      else
      {
        if (  copy_to_user(p_info->buf, buf, len) != 0
           || put_user(len, &p_info->count) != 0
           )
          err = -EFAULT;
      }

      kfree(buf);
      break;
    }

    //--------------------------------------------------------------------------------
    case CS2IOC_LOCK_WAIT:
    //--------------------------------------------------------------------------------
    #define WHERE "cs3_ioctl [CS2IOC_LOCK_WAIT]"
    {
      if ((err = down_interruptible(&dp->sema)) != 0) return err;
      session->has_sema = 1;
      return 0;
    }
    #undef WHERE

    //--------------------------------------------------------------------------------
    case CS2IOC_UNLOCK:
    //--------------------------------------------------------------------------------
    #define WHERE "cs3_ioctl [CS2IOC_UNLOCK]"
    {
      session->has_sema = 0;
      up(&dp->sema);
      return 0;
    }
    #undef WHERE

    //--------------------------------------------------------------------------------
    case CS2IOC_SETTMOUT:
    //--------------------------------------------------------------------------------
    {
      long timeout = (long)arg;

      if (  timeout < 0
         || timeout > MAX_TIMEOUT_TX_RX
         )
        return -EINVAL;

      if (timeout == 0) timeout = DEF_TIMEOUT_TX_RX;

      dp->timeout = msecs_to_jiffies(timeout);
      return 0;
    }

    //--------------------------------------------------------------------------------
    case CS2IOC_GETTMOUT:
    //--------------------------------------------------------------------------------
    {
      long *p_timeout = (long *)arg;

      if (put_user(jiffies_to_msecs(dp->timeout), p_timeout)) return -EFAULT;
      return 0;
    }

    default:
      return -EINVAL;
  }

  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_read
 *
 *****************************************************************************/
#define WHERE "cs3_read"
static int cs3_read(struct cs_session_t *session, char __user *buf, size_t max_len)
{
  struct cs3_device_t *dp = (struct cs3_device_t*)session->dp;
  int           err;
  unsigned int  ct;
  unsigned int  crc = 0;
  unsigned int  rest;     // length of remaining request
  unsigned char *src;     // points to source buffer [0/1]
  unsigned char *rx_buf;  // temporary buffer that holds block
  unsigned char *rx_data; // points to data portion
  unsigned int  blen;     // length of block
  unsigned int  len;      // data length
  unsigned int  ack;
  unsigned int  ret_len = 0;

  if (dp->rx_reset) return cs3_spm_error(WHERE, dp);

  if (  max_len == 0
     || (rest = dp->req_len) > max_len
     )
    return -ECS2BUFSIZE;

  rx_buf  = dp->buf;
  rx_data = rx_buf + PCIE_HDR_SIZE;

  dp->rx_state = STATE_READ;

  for (ct=0; ; ct++)
  {
    // wait for buffer full
    if (dp->rx_full[ct & 1] == 0)
    {
      if ((err = cs3_wait_for_rx_full(dp, ct & 1, dp->timeout, 1)) != 0)
      {
        log_error(WHERE": wait_for_rx_full(%d) returned: %d\n", ct&1, err);
        goto cleanup;
      }
    }

    if (ct & 1)
    {
      // buffer 1
      dp->rx_full[1] = 0;

      ack = ~BIT_IRQ_RX_BF1_ACK;

      blen = readl(dp->reg_base + REG_RX_LEN1);
      src = dp->rx_buf1.base_ptr;
    }
    else
    {
      // buffer 0
      dp->rx_full[0] = 0;

      ack = ~BIT_IRQ_RX_BF0_ACK;

      blen = readl(dp->reg_base + REG_RX_LEN0);
      src = dp->rx_buf0.base_ptr;
    }

    // check block size
    if (  blen < PCIE_HDR_SIZE
       || blen > PCIE_BLK_SIZE
       || (blen & 3) != 0
       )
    {
      log_error(WHERE": invalid block length: %x\n", blen);
      CLEANUP(-ECS2BADPLEN);
    }

    // copy kernel buffer to temporary buffer
    memcpy(rx_buf, src, blen);

    // send ACK
    writel(ack, dp->reg_base + REG_CS2_IRQ);

    blen -= PCIE_HDR_SIZE;

    // check sequence counter
    if (  rx_buf[1] != dp->ch_id
       || rx_buf[2] != ct
       )
    {
      log_error(WHERE": ch_id mismatch: %04x, expected: %04x\n", ((rx_buf[1] << 8) + rx_buf[2]), ((dp->ch_id << 8) + ct));
      CLEANUP(-ECS2BADSEQ);
    }

    // calculate length of payload
    len = (blen > rest) ? rest : blen;

    // calculate crc
    if (dp->crc_flag)
      crc = cs3_crc16(crc, rx_data, len);

    if (copy_to_user(buf, rx_data, len) != 0) CLEANUP(-EFAULT);

    ret_len += len;
    buf += len;

    if (rest <= blen)  break;

    rest -= blen;
  }

  if (dp->crc_flag != 0)
  {
    if ((rx_buf[3] << 8) + rx_buf[4] != crc)
    {
      log_error(WHERE": CRC mismatch: %04x, recalc: %04x\n", ((rx_buf[3] << 8) + rx_buf[4]), crc);
      dp->rx_crc_err++;
      CLEANUP(-ECS2RXCRC);
    }
  }

  dp->rx_state = STATE_IDLE;
  dp->rx_count++;
  return ret_len;

cleanup:
  dp->rx_state = STATE_IDLE;
  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_write
 *
 *****************************************************************************/
#define WHERE "cs3_write"
static int cs3_write(struct cs_session_t *session, const char __user *buf, size_t count)
{
  struct cs3_device_t *dp = (struct cs3_device_t*)session->dp;
  int           err;
  unsigned int  rest;
  unsigned int  ct = 0;
  unsigned int  crc = 0;
  unsigned char *tx_buf  = dp->buf;
  unsigned char *tx_data = tx_buf + PCIE_HDR_SIZE;
  unsigned int  len;
  unsigned int  blen;
  unsigned int  rlen;

  if (dp->tx_reset) return cs3_spm_error(WHERE, dp);
  /* first command sent after cmds ready will hit this condition */
  if (dp->rcvd_cmds_rdy)
    dp->rcvd_cmds_rdy = 0;

  dp->req_len = 0;
  dp->tx_state = STATE_WRITE;
  dp->ch_id++;

  // clear all host interrupts
  cs3_irq_clear(dp);

  dp->rx_full[0] = 0;
  dp->rx_full[1] = 0;
  dp->tx_ack[0]  = 0;
  dp->tx_ack[1]  = 0;

  for (rest = count; rest > 0; )
  {
    len = (rest > PCIE_DATA_SIZE) ? PCIE_DATA_SIZE : rest;
    blen = PCIE_HDR_SIZE + ((len + 3) & ~3);

    // build block
    if (copy_from_user(tx_data, buf, len) != 0) CLEANUP(-EFAULT);

    if (dp->crc_flag)
    {
      crc = cs3_crc16(crc, tx_data, len);
      tx_buf[0] = 1;
    }
    else
    {
      tx_buf[0] = 0;
    }

    // channel ID / sequence counter
    tx_buf[1] = dp->ch_id;
    tx_buf[2] = ct;

    // CRC: last block contains resulting crc, previous blocks an intermediate crc
    tx_buf[3] = crc >> 8;
    tx_buf[4] = crc;

    // length: first block contains full length, subsequent blocks the rest length
    rlen = rest;

    tx_buf[5] = rlen >> 16;
    tx_buf[6] = rlen >> 8;
    tx_buf[7] = rlen;

    // wait for ACK of block (causes timing issues)
    /* if (ct >= 2)
    {
      if ((err = cs3_wait_for_tx_ack(dp, ct&1, dp->timeout)) != 0)
      {
        log_error(WHERE": cs3_wait_for_tx_ack(%d) returned: %d\n", ct&1, err);
        goto cleanup;
      }
    } */

    if ((ct & 1) == 0)
    {
      __iowrite32_copy((void *)dp->tx_buf0, tx_buf, blen>>2);
    }
    else
    {
      __iowrite32_copy((void *)dp->tx_buf1, tx_buf, blen>>2);
    }

    // wait for ACK of previous block
    if (ct != 0)
    {
      int idx = (ct & 1) ^ 1;

      if ((err = cs3_wait_for_tx_ack(dp, idx, dp->timeout)) != 0)
      {
        log_error(WHERE": cs3_wait_for_tx_ack(%d) returned: %d\n", idx, err);
        goto cleanup;
      }
    }

    // send block
    if (ct & 1)
    {
      // buffer 1
      dp->tx_ack[1] = 0;
      writel(blen, dp->reg_base + REG_TX_LEN1);
      writel(~BIT_IRQ_TX_BF1_FULL, dp->reg_base + REG_CS2_IRQ);
    }
    else
    {
      // buffer 0
      dp->tx_ack[0] = 0;
      writel(blen, dp->reg_base + REG_TX_LEN0);
      writel(~BIT_IRQ_TX_BF0_FULL, dp->reg_base + REG_CS2_IRQ);
    }

    readl(dp->reg_base + REG_VERSION);  // flush PCI

    buf += len;
    rest -= len;
    ct++;
  }

  dp->tx_count++;
  dp->tx_state = STATE_IDLE;

  return count;

cleanup:
  dp->tx_state = STATE_IDLE;
  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_proc_show
 *
 ******************************************************************************/
static int cs3_proc_show(struct seq_file *m, void *v)
{
  int                 err = 0;
  char                *buf = NULL;
  int                 len;
  struct cs3_device_t *dp = (struct cs3_device_t*)m->private;

  if (dp == NULL) return -ENODEV;

  if ((buf = kzalloc(PAGE_SIZE, GFP_KERNEL)) == NULL) return -ENOMEM;

  if ((len = cs3_info(dp, buf, PAGE_SIZE)) < 0) CLEANUP(len);

  seq_printf(m, buf);

cleanup:
  kfree(buf);
  return err;
}

/******************************************************************************
 *
 * cs3_proc_write
 *
 ******************************************************************************/
#define WHERE "cs3_proc_write"
static ssize_t cs3_proc_write(struct file *file, const char __user *user, size_t count, loff_t *off)
{
//struct cs3_device_t *dp = (struct cs3_device_t *)PDE_DATA(file_inode(file));
  struct cs3_device_t *dp = compat_file_to_PDE_DATA(file);
  int   err = 0;
  char  *buf = NULL;
  int   i;

  if ((buf = kmalloc(count+1, GFP_KERNEL)) == NULL) return -ENOMEM;

  if (copy_from_user(buf, user, count) != 0) CLEANUP(-EFAULT);
  buf[count] = 0;

  if (strncasecmp(buf, "RESET", 5) == 0)
  {
    cs3_reset(dp);
  }
  else if (strncasecmp(buf, "SHUTDOWN", 8) == 0)
  {
    unsigned int mode = 0;

    cs_get_args(buf+8, "u", &mode);

    cs3_shutdown(dp, mode);
  }
  else if (strncasecmp(buf, "LOGLEVEL", 8) == 0)
  {
    unsigned int new = LogLevel;

    if (cs_get_args(buf+8, "u", &new) > 0)
    {
      printk("LogLevel changed from % d to %d\n", LogLevel, new);
      LogLevel = new;
    }
    else
    {
       printk("LogLevel: %d\n", LogLevel);
    }
  }
  else if (strncasecmp(buf, "REG", 3) == 0)
  {
    char line[80];
    char *p_x = NULL;
    int  ofs;

    for (i=0, ofs=0; i<32; i++, ofs += 4)
    {
      u32 regval = readl(dp->reg_base + ofs);

      if ((i & 3) == 0) p_x = line + sprintf(line, "%4x |", ofs);

      p_x += sprintf(p_x, " %08X\n", regval) - 1;

      if ((i & 3) == 3)
      {
        printk(line);
        p_x = NULL;
      }
    }
    msleep(100);
  }
  else
  {
    log_error(WHERE": invalid argument: %s\n", buf);
    CLEANUP(-EINVAL);
  }

  if (err < 0)
  {
    log_error(WHERE": '%s' returned: %d\n", buf, err);
    goto cleanup;
  }

  (void)dp;

cleanup:
  if (buf != NULL) kfree(buf);

  return (err != 0) ? err : count;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_proc_open
 *
 ******************************************************************************/
static int cs3_proc_open(struct inode *inode, struct file *file)
{
//return single_open(file, cs3_proc_show, PDE_DATA(inode));
  return single_open(file, cs3_proc_show, compat_PDE_DATA(inode));
}

//-----------------------------------------------------------------------------
static const struct file_operations cs3_proc_ops =
//-----------------------------------------------------------------------------
{
  .owner   = THIS_MODULE,
  .open    = cs3_proc_open,
  .read    = seq_read,
  .write   = cs3_proc_write,
  .llseek  = seq_lseek,
  .release = single_release,
};


/******************************************************************************
 *
 * cs3_remove
 *
 *****************************************************************************/
#define WHERE "cs3_remove"
int cs3_remove(struct cs3_device_t *dp)
{
  struct pci_dev *pci_dev;

  if (dp == NULL) return -EINVAL;

  pci_dev = dp->pci_dev;

  if (dp->reg_base != NULL) 
  {
    cs3_irq_disable(dp);    
    writel(0, dp->reg_base + REG_DMA0_ADDR);
    writel(0, dp->reg_base + REG_DMA1_ADDR);
  }

  if (pci_dev != NULL)
  {
    cs3_irq_free(dp);
    pci_disable_device(pci_dev);
  }

  cs3_dma_free(dp, &dp->rx_buf0);
  cs3_dma_free(dp, &dp->rx_buf1);

  if (dp->task != NULL) kfree(dp->task);

  if (dp->buf != NULL) kfree(dp->buf);

  cs3_io_unmap(dp);

  if (pci_dev != NULL) pci_release_regions(pci_dev);

  memset(dp, 0, sizeof(struct cs3_device_t));
  kfree(dp);

  DeviceCount--;

  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs3_probe
 *
 *****************************************************************************/
#define WHERE "cs3_probe"
int cs3_probe(struct pci_dev *pci_dev, struct cs3_device_t **pp_dp)
{
  int err;
  struct cs3_device_t *dp;

  // create device
  if ((dp = kmalloc(sizeof(struct cs3_device_t), GFP_KERNEL)) == NULL) return -ENOMEM;
  memset(dp, 0, sizeof(struct cs3_device_t));

  dp->pci_dev = pci_dev;
  dp->proc_ops = &cs3_proc_ops;

  dp->p_remove   = (int(*)(struct cs_device_t*))cs3_remove;
  dp->p_shutdown = (int(*)(struct cs_device_t*,unsigned int))cs3_shutdown;
  dp->p_reset    = (int(*)(struct cs_device_t*))cs3_reset;

  dp->p_open     = cs3_open;
  dp->p_close    = cs3_close;
  dp->p_ioctl    = cs3_ioctl;
  dp->p_read     = cs3_read;
  dp->p_write    = cs3_write;

  // map memory mapped register
  if ((err = pci_request_regions(pci_dev, "cs3")) != 0)
  {
    log_error(WHERE": pci_request_regions returned: %d\n", err);
    CLEANUP(-ENODEV);
  }

  if ((err = cs3_io_map(dp)) != 0)
  {
    log_error(WHERE": cs3_io_map(1) returned: %d", err);
    goto cleanup;
  }  

  // enable device
  if ((err = pci_enable_device(pci_dev)) != 0)
  {
    log_error(WHERE": pci_enable_device returned: %d\n", err);
    goto cleanup;
  }
  
  cs3_irq_disable(dp);

  // set master
  pci_set_master(pci_dev);

  // set DMA mask
  if ((err = pci_set_consistent_dma_mask(pci_dev, DMA_BIT_MASK(32))) != 0)
  {
    log_error(WHERE": pci_set_consistent_dma_mask(32) returned: %d\n", err);
    goto cleanup;
  }

  // allocate DMA memory
  if ((err = cs3_dma_alloc(dp, PCIE_BLK_SIZE, &dp->rx_buf0)) != 0)
  {
    log_error(WHERE": cs3_dma_alloc(rx_buf0) returned: %d\n", err);
    goto cleanup;
  }

  if ((err = cs3_dma_alloc(dp, PCIE_BLK_SIZE, &dp->rx_buf1)) != 0)
  {
    log_error(WHERE": cs3_dma_alloc(rx_buf1) returned: %d\n", err);
    goto cleanup;
  }

  writel(dp->rx_buf0.phys_addr_lo, dp->reg_base + REG_DMA0_ADDR);
  writel(dp->rx_buf1.phys_addr_lo, dp->reg_base + REG_DMA1_ADDR);

  init_waitqueue_head(&dp->tx_queue);
  init_waitqueue_head(&dp->rx_queue);
  init_waitqueue_head(&dp->spm_queue);

  spin_lock_init(&dp->task_lock);

  // allocate tasklet
  if ((dp->task = kmalloc(sizeof(struct tasklet_struct), GFP_KERNEL)) == NULL)
  {
    log_error(WHERE": kmalloc [tasklet] failed\n");
    CLEANUP(-ENOMEM);
  }

  tasklet_init(dp->task, (void(*)(unsigned long))cs3_task_proc, (unsigned long)dp);

  // connect interrupt
  if ((err = cs3_irq_request(dp)) != 0)
  {
    log_error(WHERE": cs3_irq_request returned: %d\n", err);
    goto cleanup;
  }

  // allocate temporary chunk buffer
  if ((dp->buf = kmalloc(PCIE_BLK_SIZE, GFP_KERNEL)) == NULL)
  {
    log_error(WHERE": unable to alloc memory for buf\n");
    goto cleanup;
  }

  // initialize device
  dp->tx_ack[0] = 1;
  dp->tx_ack[1] = 1;

  dp->ch_id = 0;
  dp->timeout = msecs_to_jiffies(DEF_TIMEOUT_TX_RX);

  sema_init(&dp->sema, 1);

  dp->tx_count = 0;
  dp->rx_crc_err = 0;
  dp->rx_count = 0;

  dp->spm_state = 0;
  dp->crc_flag = 1;

  // precalculate CRC tables
  if (DeviceCount++ == 0)
  {
    unsigned char buf[6];
    int i;

    memset(buf, 0, 6);

    for (i = 0; i < 256; i++)
    {
      buf[0] = i;
      Crc_tab1[i] = cs3_crc16_slow(0, buf, 3);
      Crc_tab2[i] = cs3_crc16_slow(0, buf, 4);
      Crc_tab3[i] = cs3_crc16_slow(0, buf, 5);
      Crc_tab4[i] = cs3_crc16_slow(0, buf, 6);
    }
  }

  // enable interrupts
  cs3_irq_enable(dp);

  *pp_dp = dp;
  return 0;

cleanup:
  cs3_remove(dp);
  *pp_dp = NULL;
  return err;
}
#undef WHERE


