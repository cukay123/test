/***************************************************************************************************
 *
 * Description: Linux device driver for CryptoServer-AR
 *
 * Author     : Utimaco IS GmbH
 *              Germanusstrasse 4
 *              52080 Aachen
 *              Germany
 *              info@utimaco.com
 *
 * Copyright (C) 2020 Utimaco IS GmbH <www.utimaco.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#include <linux/version.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/poll.h>

#include "cryptoserver.h"
#include "compat.h"

/******************************************************************************
 *
 * Definitions
 *
 ******************************************************************************/
#define DRIVER_NAME           "cryptoserver"
#define DRIVER_VERSION_STR    "4.1.17"

#define DRIVER_BUILD          ""

#ifdef TRACE
#undef DRIVER_BUILD
#define DRIVER_BUILD          "[TRACE]"
#endif

#ifdef DEBUG
#undef DRIVER_BUILD
#define DRIVER_BUILD          "[DEBUG]"
#endif

#define CLASS_NAME            "hsm"
#define CHRDEV_NAME           "CryptoServer"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
#error Only for kernel versions >= 2.6.32
#endif

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Utimaco IS GmbH");
MODULE_DESCRIPTION("CryptoServer device driver");
MODULE_VERSION(DRIVER_VERSION_STR);


/******************************************************************************
 *
 * Globals
 *
 *****************************************************************************/

// module parameter
unsigned int LogLevel = LOG_LEVEL_INFO;
module_param(LogLevel, int, 0);
MODULE_PARM_DESC(LogLevel, " 0:none, 1:error, 2:warning, 3:info [default], 4:trace, 5:debug");

unsigned int ShutdownMode = 2;
module_param(ShutdownMode, int, 0);
MODULE_PARM_DESC(ShutdownMode, " 0:none, 1:suspend, 2:halt [default]");

unsigned int MsiMode = 1;
module_param(MsiMode, int, 0);
MODULE_PARM_DESC(MsiMode, " 0:legacy, 1:MSI/MSI-X [default]");


const char DriverVersionString[] = DRIVER_VERSION_STR " " DRIVER_BUILD;

static int                MajorNumber = -1;
static struct class       *DeviceClass = NULL;

#define MAX_DEVICES   16
static struct cs_device_t *Devices[MAX_DEVICES];

const char *LogLevelTxt[] =
{
  "[0] None",
  "[1] Error",
  "[2] Warning",
  "[3] Info",
  "[4] Trace",
  "[5] Debug",
  "?6!",
  "?7!"
};

const char *ShutdownModeTxt[] =
{
   "[0] none",
   "[1] suspend",
   "[2] halt",
   "?3!"
};

const char *IrqModeTxt[] =
{
   "legacy",
   "MSI",
   "MSI-multi",
   "MSI-X"
};

const char *ModelTxt[] =
{
  "0 [?]",
  "1 [CS2]",
  "2 [Se-Series]",
  "3 [?]",
  "4 [CSe-Series]",
  "5 [Se2-Series]",
  "6 [?]"
  "7 [?]"
};

extern int  cs2_probe(struct pci_dev *pci_dev, struct cs_device_t **pp_dp);
extern int  cs3_probe(struct pci_dev *pci_dev, struct cs_device_t **pp_dp);
extern int  csx_probe(struct pci_dev *pci_dev, struct cs_device_t **pp_dp) __attribute__((weak));

static int (*probe_func[])(struct pci_dev *pci_dev, struct cs_device_t **pp_dp) =
{
  NULL,
  cs2_probe,
  cs3_probe,
  NULL,
  cs3_probe,
  cs3_probe,
  NULL,
  csx_probe
};

/******************************************************************************
 *
 * Macros
 *
 *****************************************************************************/

// force newer defination in order to prevent compiler warnings on some platforms
#undef IS_ERR_VALUE
#define IS_ERR_VALUE(x) unlikely((unsigned long)(void *)(x) >= (unsigned long)-MAX_ERRNO)


/******************************************************************************
 *
 * cs_xtrace
 *
 *****************************************************************************/
void cs_xtrace(char *txt, void *data, int len)
{
  static char hex[]="0123456789abcdef";

  int   a;
  char  *x;
  char  *dt = (char *)data;
  char  buff1[40];
  char  buff2[20];
  int   adr = 0;

  if (txt != NULL) printk("%s\n", txt);

  while (len > 0)
  {
    for(a=0, x=buff1; a<16 && a<len; a++)
    {
      if ((a&3) == 0) *x++ = ' ';
      if ((a&7) == 0) *x++ = ' ';
      *x++ = hex[(dt[a]>>4)&15];
      *x++ = hex[dt[a]&15];
    }
    *x=0;

    for(a=0, x=buff2; a<16 && a<len; a++)
    {
      *x++ = (dt[a]>' ' && dt[a]<0x7f) ? dt[a] : ' ';
    }
    *x=0;

    printk("%-38s |%-16s|\n", buff1, buff2);
    len -= 16;
    adr += 16;
    dt += 16;
  }
}

/******************************************************************************
 *
 * cs_get_args
 *
 ******************************************************************************/
int cs_get_args(char *p_arg, const char *fmt, ...)
{
  va_list   ap;
  char      *p_x = p_arg;
  int       num_args = 0;

  if (*p_x != '=') return 0;
  p_x++;

  va_start(ap, fmt);

  while (p_x != NULL)
  {
    switch (*fmt++)
    {
      case 'i':
      {
        int *p_int = va_arg(ap, int*);

        if (p_int == NULL) break;

        *p_int = simple_strtol(p_x, NULL, 0);
        break;
      }

      case 'u':
      {
        int *p_uint = va_arg(ap, unsigned int*);

        if (p_uint == NULL) break;

        *p_uint = simple_strtol(p_x, NULL, 0);
        break;
      }

      /* case 'l':
      {
        long long *p_long = va_arg(ap, long long*);

        if (p_long == NULL) break;

        *p_long = simple_strtoll(p_x, NULL, 0);
        break;
      } */

      case 's':
      {
        char **pp_chr = va_arg(ap, char**);

        if (pp_chr == NULL) break;

        *pp_chr = p_x;
        break;
      }

      default:
        goto cleanup;
    }

    num_args++;

    if ((p_x = strchr(p_x, ',')) == NULL) break;
    *p_x++ = 0;
  }

cleanup:
  va_end(ap);
  return num_args;
}

/******************************************************************************
 *
 * cs_open
 *
 *****************************************************************************/
#define WHERE "cs_open"
static int cs_open(struct inode *inode, struct file *file)
{
  int err;
  int minor;
  struct cs_device_t *dp;
  struct cs_session_t *session;

  if ((minor = iminor(inode)) >= MAX_DEVICES)
  {
    log_error(WHERE": invalid minor number: %d\n", minor);
    return(-ENODEV);
  }

  dp = Devices[minor];
  if (dp == NULL) {
    return -ENODEV;
  }

  if (dp->pci_dev == NULL)
  {
    log_error(WHERE": no such PCI device\n");
    return(-ENODEV);
  }

  if ((session = kzalloc(sizeof(struct cs_session_t), GFP_KERNEL)) == NULL) return(-ENOMEM);

  session->dp = dp;
  session->file = file;
  spin_lock_init(&session->lock);

  if ((err = dp->p_open(session)) != 0)
  {
    log_error("%s:"WHERE": open returned: %d\n", dp->device_name, err);
    goto cleanup;
  }

  file->private_data = session;
  return 0;

cleanup:
  if (session != NULL) kfree(session);
  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs_close
 *
 *****************************************************************************/
#define WHERE "cs_close"
static int cs_close(struct inode *inode, struct file *file)
{
  int err;
  struct cs_session_t *session = file->private_data;
  struct cs_device_t *dp;

  if (session == NULL) return -EINVAL;

  if ((dp = session->dp) == NULL) CLEANUP(-ENODEV);

  dp->p_close(session);

cleanup:
  kfree(session);

  file->private_data = NULL;
  return err;
}
#undef WHERE

/******************************************************************************
 *
 * cs_ioctl_unlocked
 *
 *****************************************************************************/
static long cs_ioctl_unlocked(struct file *file, unsigned int cmd, unsigned long arg)
{
  struct cs_session_t *session = file->private_data;
  struct cs_device_t *dp;

  if (session == NULL) return -EINVAL;

  if ((dp = session->dp) == NULL) return -ENODEV;

  return dp->p_ioctl(session, cmd, arg);
}

/******************************************************************************
 *
 * cs_read
 *
 *****************************************************************************/
static ssize_t cs_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
  struct cs_session_t *session = file->private_data;
  struct cs_device_t *dp;

  if (session == NULL) return -EINVAL;

  if ((dp = session->dp) == NULL) return -ENODEV;

  return dp->p_read(session, buf, count);
}

/******************************************************************************
 *
 * cs_write
 *
 *****************************************************************************/
static ssize_t cs_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
  struct cs_session_t *session = file->private_data;
  struct cs_device_t *dp;

  if (session == NULL) return -EINVAL;

  if ((dp = session->dp) == NULL) return -ENODEV;

  return dp->p_write(session, buf, count);
}

static unsigned int cs_poll(struct file *file, poll_table *wait)
{
  struct cs_session_t *session = file->private_data;
  struct cs_device_t *dp;

  if (session == NULL)
    return -EINVAL;
  dp = session->dp;
  if (!dp)
    return -ENODEV;
  if (!dp->p_poll)
    return -EINVAL;

  return dp->p_poll(session, file, wait);
}

//-----------------------------------------------------------------------------
static struct file_operations cs_file_ops =
//-----------------------------------------------------------------------------
{
  owner:          THIS_MODULE,
  open:           cs_open,
  release:        cs_close,
  read:           cs_read,
  write:          cs_write,
  poll:           cs_poll,
  unlocked_ioctl: cs_ioctl_unlocked,
  compat_ioctl:   cs_ioctl_unlocked
};


/******************************************************************************
 *
 * cs_suspend
 *
 ******************************************************************************/
#define WHERE "cs_suspend"
static int cs_suspend(struct pci_dev *pci_dev, pm_message_t state)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);

  log_info(WHERE": device [%s] suspending [%04x]\n", dp->device_name, state.event);

  switch (state.event)
  {
    case PM_EVENT_FREEZE:
    case PM_EVENT_SUSPEND:
    case PM_EVENT_HIBERNATE:
      pci_save_state(pci_dev);

      if (dp->p_shutdown != NULL) dp->p_shutdown(dp, ShutdownMode);
      break;
  }

  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs_resume
 *
 ******************************************************************************/
#define WHERE "cs_resume"
static int cs_resume(struct pci_dev *pci_dev)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);

  log_info(WHERE": device [%s] resuming\n", dp->device_name);

  pci_restore_state(pci_dev);

  if (dp->p_reset != NULL) dp->p_reset(dp);

  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs_shutdown
 *
 ******************************************************************************/
#define WHERE "cs_shutdown"
static void cs_shutdown(struct pci_dev *pci_dev)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);

  log_info(WHERE": device [%s] going to shut down [%d]\n", dp->device_name, system_state);

  switch (system_state)
  {
    case SYSTEM_HALT:
    case SYSTEM_POWER_OFF:
      if (dp->p_shutdown != NULL) dp->p_shutdown(dp, ShutdownMode);
      break;

    case SYSTEM_RESTART:
    default:
      break;
  }
}
#undef WHERE

/******************************************************************************
 *
 * cs_error_detected
 *
 *****************************************************************************/
#define WHERE "cs_error_detected"
pci_ers_result_t cs_error_detected(struct pci_dev *pci_dev, enum pci_channel_state state)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);

  log_error(WHERE": device [%s]: error detected [%d]\n", dp->device_name, state);

//return PCI_ERS_RESULT_CAN_RECOVER;
  return PCI_ERS_RESULT_NEED_RESET;
//return PCI_ERS_RESULT_DISCONNECT;
}
#undef WHERE

/******************************************************************************
 *
 * cs_slot_reset
 *
 *****************************************************************************/
#define WHERE "cs_slot_reset"
pci_ers_result_t cs_slot_reset(struct pci_dev *pci_dev)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);

  log_info(WHERE": device [%s]: slot was reset\n", dp->device_name);

  return PCI_ERS_RESULT_NONE;
}
#undef WHERE

static void cs_reset_prepare(struct pci_dev *pci_dev)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);
  if (dp->p_reset_prepare)
    dp->p_reset_prepare(dp);
}

static void cs_reset_done(struct pci_dev *pci_dev)
{
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);
  if (dp->p_reset_done)
    dp->p_reset_done(dp);
}

static void __maybe_unused cs_reset_notify(struct pci_dev *pci_dev, bool prepare)
{
  if (prepare) {
    cs_reset_prepare(pci_dev);
  } else {
    cs_reset_done(pci_dev);
  }
}

/******************************************************************************
 *
 * cs_remove
 *
 ******************************************************************************/
#define WHERE "cs_remove"
static void cs_remove(struct pci_dev *pci_dev)
{
  int err;
  struct cs_device_t *dp = pci_get_drvdata(pci_dev);
  int idx;

  if (dp == NULL) return;

  if ((idx = dp->minor) >= MAX_DEVICES)
  {
    log_error(WHERE": invalid device index: %d\n", idx);
    return;
  }

  if (Devices[idx] == NULL)
  {
    log_error(WHERE": no device for index: %d\n", idx);
    return;
  }

  if (dp != Devices[idx])
  {
    log_error(WHERE": device index mismatch: %d\n", idx);
    return;
  }

  // remove proc entry
  if (dp->proc_entry != NULL)
  {
    remove_proc_entry(dp->proc_name, NULL);
    dp->proc_entry = NULL;
    log_trace(WHERE": removed proc entry: %s\n", dp->proc_name);
  }

  // delete device node
  device_destroy(DeviceClass, MKDEV(MajorNumber, idx));

  // call device specific remove function
  if (dp->p_remove != NULL)
  {
    if ((err = dp->p_remove(dp)) != 0)
    {
      log_error(WHERE": remove [%d] returned: %d\n", idx, err);
    }
  }

  Devices[idx] = NULL;
  pci_set_drvdata(pci_dev, NULL);

  log_info(WHERE": device [%d] removed\n", idx);
}
#undef WHERE


/******************************************************************************
 *
 * cs_probe
 *
 ******************************************************************************/
#define WHERE "cs_probe"
static int cs_probe(struct pci_dev *pci_dev, const struct pci_device_id *id)
{
  int                 err = 0;
  unsigned int        model = id->driver_data & 0xF;
  struct cs_device_t  *dp = NULL;
  struct device       *parent = &pci_dev->dev;
  struct device       *device;
  int (*p_probe)(struct pci_dev *pci_dev, struct cs_device_t **pp_dp);
  int                 idx;

  log_info(WHERE": device found: %04x:%04x %04x:%04x model: %d, class: %x, irq: %d\n",
                   pci_dev->vendor,
                   pci_dev->device,
                   pci_dev->subsystem_vendor,
                   pci_dev->subsystem_device,
                   model,
                   pci_dev->class,
                   pci_dev->irq);

  // get free entry in device table
  for (idx=0; idx<MAX_DEVICES; idx++)
  {
    if (Devices[idx] == NULL) break;
  }

  if (idx >= MAX_DEVICES)
  {
    log_error(WHERE": maximum number of devices reached\n");
    return -ENODEV;
  }

  if (  model >= DIM(probe_func)
     || (p_probe = probe_func[model]) == NULL
     )
  {
    log_error(WHERE": unsupported device/model: %d\n", model);
    CLEANUP(-ENODEV);
  }

  // call device specific probe function
  if ((err = p_probe(pci_dev, &dp)) != 0)
  {
    log_error(WHERE": probe[%d] returned: %d\n", model, err);
    goto cleanup;
  }

  dp->minor = idx;
  dp->model = model;
  strncpy(dp->slot, dev_name(&pci_dev->dev), sizeof(dp->slot));
  sprintf(dp->device_name, "cs2.%d", idx);
  sprintf(dp->proc_name, "driver/cs2.%d", idx);

  spin_lock_init(&dp->lock);

  Devices[idx] = dp;
  pci_set_drvdata(pci_dev, dp);

  // create proc entry
  if ((dp->proc_entry = proc_create_data(dp->proc_name, 0666, NULL, dp->proc_ops, dp)) == NULL)
  {
    log_error(WHERE": proc_create_data(%s) failed\n", dp->proc_name);
    CLEANUP(-ENOMEM);
  }

  log_trace(WHERE": successfully created proc entry: %s", dp->proc_name);

  // create device node
  device = device_create(DeviceClass, parent, MKDEV(MajorNumber, dp->minor), NULL, dp->device_name);

  if (IS_ERR_VALUE(device))
  {
    err = PTR_ERR(device);
    log_error(WHERE": device_create(%s) returned: %d\n", dp->device_name, err);
    goto cleanup;
  }

  log_info(WHERE": successfully created device node: %s\n", dp->device_name);

  log_info(WHERE": probe [%d] OK\n", dp->minor);
  return 0;

cleanup:
  cs_remove(pci_dev);
  return err;
}
#undef WHERE


//-----------------------------------------------------------------------------
static struct pci_device_id cs_pci_tbl[] =
//-----------------------------------------------------------------------------
{
  { 0x11e3, 0x0006,             // QuickLogic vendor / device id
    0x168a, 0x1110,             // Utimaco sub-vendor / sub-device id
    0, 0, 1                     // model := 1
  },
  { 0x168a, 0x2086,             // Utimaco vendor / device id
    PCI_ANY_ID, PCI_ANY_ID,
    0, 0,                       // class, class mask
    2                           // model := 2 (Se-Series)
  },
  { 0x168a, 0xC040,             // Utimaco vendor / device id
    0x168a, 0x2708,             // Utimaco sub-vendor / sub-device id
    0, 0,                       // class, class mask
    4                           // model := 4 (CSe-Series)
  },
  { 0x168a, 0xC051,             // Utimaco vendor / device id
    0x168a, 0x2708,             // Utimaco sub-vendor / sub-device id
    0, 0,                       // class, class mask
    5                           // model := 5 (Se2-Series)
  },
  {
    0x168A, 0xC070,
    PCI_ANY_ID, PCI_ANY_ID,
    0, 0,                       // class, class mask
    7                           // model := 7
  },
  { 0 }
};

//-----------------------------------------------------------------------------
static const struct pci_error_handlers cs_error_handler =
//-----------------------------------------------------------------------------
{
  .error_detected = cs_error_detected,
  .slot_reset     = cs_slot_reset,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,13,0)
  .reset_prepare  = cs_reset_prepare,
  .reset_done     = cs_reset_done,
#elif (  LINUX_VERSION_CODE >= KERNEL_VERSION(3,16,0) \
      && !defined(CONFIG_SUSE_KERNEL) \
      )
  .reset_notify   = cs_reset_notify,
#endif
};


MODULE_DEVICE_TABLE(pci, cs_pci_tbl);
MODULE_ALIAS("cs2");

//-----------------------------------------------------------------------------
static struct pci_driver cs_driver =
//-----------------------------------------------------------------------------
{
  .name         = DRIVER_NAME,
  .id_table     = cs_pci_tbl,
  .probe        = cs_probe,
  .remove       = cs_remove,
  .suspend      = cs_suspend,
//.suspend_late = cs_suspend_late,
//.resume_early = cs_resume_early,
  .resume       = cs_resume,
  .shutdown     = cs_shutdown,
  .err_handler  = &cs_error_handler
};

/******************************************************************************
 *
 * cs_devnode
 *
 *****************************************************************************/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 33)
static char *cs_devnode(struct device *dev, umode_t *mode)
{
  if (mode != NULL)
  {
    *mode = 0666;
    log_trace("cs_devnode: [%s] mode: %u\n", dev_name(dev), *mode);
  }

  // return NULL;
  return kasprintf(GFP_KERNEL, "%s", dev_name(dev));
}
#endif

/******************************************************************************
 *
 * cs_init_module
 *
 ******************************************************************************/
#define WHERE "cs_init_module"
static int cs_init_module(void)
{
  int err;

  // init global variables
  DeviceClass = NULL;

  memset(Devices, 0, sizeof(Devices));

  log_info(WHERE": "DRIVER_NAME" driver version "DRIVER_VERSION_STR" "DRIVER_BUILD"\n");
  log_trace(WHERE": LogLevel    : %s\n", LogLevelTxt[LogLevel & 7]);
  log_trace(WHERE": MsiMode     : %d\n", MsiMode);
  log_trace(WHERE": ShutdownMode: %s\n", ShutdownModeTxt[ShutdownMode & 3]);
  
  if (LogLevel > LOG_LEVEL_DEBUG) LogLevel = LOG_LEVEL_DEBUG;
  MsiMode &= 1;
  ShutdownMode &= 3;

#if (RHEL_RELEASE_CODE != 0)
  log_info(WHERE": RHEL_RELEASE_CODE: 0x%x\n", RHEL_RELEASE_CODE);
  log_trace(WHERE": RHEL_MAJOR       : 0x%x\n", RHEL_MAJOR);
  log_trace(WHERE": RHEL_MINOR       : 0x%x\n", RHEL_MINOR);
#endif

#if (SLE_VERSION_CODE != 0)
  log_info(WHERE": SLE_VERSION_CODE: 0x%x\n", SLE_VERSION_CODE);
#endif

  // create device class
  DeviceClass = class_create(THIS_MODULE, CLASS_NAME);

  if (IS_ERR_VALUE(DeviceClass))
  {
    err = PTR_ERR(DeviceClass);
    DeviceClass = NULL;
    log_error(WHERE": class_create(%s) returned: %d\n", CLASS_NAME, err);
    return err;
  }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 33)
  DeviceClass->devnode = cs_devnode;
#endif

  // register character device
  MajorNumber = register_chrdev(0, CHRDEV_NAME, &cs_file_ops);

  if (MajorNumber < 0)
  {
    err = MajorNumber;
    log_error(WHERE": register_chrdev(%s) returned: %d\n", CHRDEV_NAME, err);
    return err;
  }

  log_info(WHERE": Major Number: %d\n", MajorNumber);

  // register driver
  if ((err = pci_register_driver(&cs_driver)) != 0)
  {
    log_error(WHERE": pci_register_driver returned: %d\n", err);
    return err;
  }

  log_info(WHERE": "DRIVER_NAME" driver was successfully registered\n");

  return 0;
}
#undef WHERE

/******************************************************************************
 *
 * cs_cleanup_module
 *
 ******************************************************************************/
#define WHERE "cs_cleanup_module"
static void cs_cleanup_module(void)
{
  // unregister driver
  pci_unregister_driver(&cs_driver);

  if (DeviceClass != NULL)
  {
    if (MajorNumber >= 0)
    {
      // unregister character device
      unregister_chrdev(MajorNumber, CHRDEV_NAME);
    }

    class_destroy(DeviceClass);
  }

  memset(Devices, 0, sizeof(Devices));

  log_info(WHERE": "DRIVER_NAME" driver unregistered\n");
}
#undef WHERE

module_init(cs_init_module);
module_exit(cs_cleanup_module);
