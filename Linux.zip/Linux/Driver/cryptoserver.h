#ifndef __CRYPTOSERVER_H__
#define __CRYPTOSERVER_H__


/******************************************************************************
 *
 * Definitions
 *
 ******************************************************************************/
#define IRQ_MODE_LEGACY       0
#define IRQ_MODE_MSI          1
#define IRQ_MODE_MSI_MULTI    2
#define IRQ_MODE_MSIX         3

#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
  #define CS_BIG_ENDIAN
#else
  #define CS_LITTLE_ENDIAN
#endif

/******************************************************************************
 *
 * Types
 *
 ******************************************************************************/

// IO memory
struct cs_iomem_t
{
  unsigned char __iomem  *base_ptr;
  union
  {
    struct
    {
#ifdef CS_BIG_ENDIAN
      u32 phys_addr_hi;
      u32 phys_addr_lo;
#else
      u32 phys_addr_lo;
      u32 phys_addr_hi;
#endif
    };

    phys_addr_t phys_addr;
  };

  unsigned long size;
};

// DMA buffer
struct cs_dmabuf_t
{
  void  *base_ptr;
  union
  {
    struct
    {
#ifdef CS_BIG_ENDIAN
      u32 phys_addr_hi;
      u32 phys_addr_lo;
#else
      u32 phys_addr_lo;
      u32 phys_addr_hi;
#endif
    };

    phys_addr_t phys_addr;
  };

  unsigned int  size;
};

struct cs_device_t;

// Session
struct cs_session_t
{
  struct cs_device_t  *dp;
  struct file         *file;
  u32                 messages[4];
  spinlock_t          lock;
  unsigned int        has_sema;
  unsigned int        gen;
};

// Device
#define DEVICE_STRUCT_COMMON                                                                  \
  int           minor;                                                                        \
  unsigned int  model;                                                                        \
  char          device_name[8];                                                               \
  char          proc_name[16];                                                                \
  char          slot[16];                                                                     \
  spinlock_t    lock;                                                                         \
  unsigned int  irq_mode;                                                                     \
                                                                                              \
  struct pci_dev                *pci_dev;                                                     \
  struct proc_dir_entry         *proc_entry;                                                  \
  const struct file_operations  *proc_ops;                                                    \
                                                                                              \
  int (*p_remove)   (struct cs_device_t *dp);                                                 \
  int (*p_shutdown) (struct cs_device_t *dp, unsigned int mode);                              \
  int (*p_reset)    (struct cs_device_t *dp);                                                 \
  void (*p_reset_prepare)(struct cs_device_t *dp);                                            \
  void (*p_reset_done)(struct cs_device_t *dp);                                               \
                                                                                              \
  int (*p_open)     (struct cs_session_t *session);                                           \
  int (*p_close)    (struct cs_session_t *session);                                           \
  int (*p_ioctl)    (struct cs_session_t *session, unsigned int cmd, unsigned long arg);      \
  int (*p_read)     (struct cs_session_t *session, char __user *buf, size_t max_len);         \
  int (*p_write)    (struct cs_session_t *session, const char __user *buf, size_t max_len);   \
  unsigned int (*p_poll)(struct cs_session_t *session, struct file *filp, struct poll_table_struct *wait);  \

struct cs_device_t
{
  DEVICE_STRUCT_COMMON
};

/******************************************************************************
 *
 * Macros
 *
 *****************************************************************************/
#define CLEANUP(code)      { err = (code); goto cleanup; }

#define DIM(a)             ( sizeof((a)) / sizeof((a)[0]) )

#define MIN(a,b)            (a)<(b)?(a):(b)
#define MAX(a,b)            (a)>(b)?(a):(b)

#define WLEN(a)             (((a) + 3) / 4)

#define XSTR(x)             STR(x)
#define STR(x)              #x


// logging
#define LOG_LEVEL_NONE      0
#define LOG_LEVEL_ERROR     1
#define LOG_LEVEL_WARNING   2
#define LOG_LEVEL_INFO      3
#define LOG_LEVEL_TRACE     4
#define LOG_LEVEL_DEBUG     5

#define log_error(format,...)     { if (LogLevel >= LOG_LEVEL_ERROR)   printk("!" format, ##__VA_ARGS__); }
#define log_warning(format,...)   { if (LogLevel >= LOG_LEVEL_WARNING) printk("?" format, ##__VA_ARGS__); }
#define log_info(format,...)      { if (LogLevel >= LOG_LEVEL_INFO)    printk(":" format, ##__VA_ARGS__); }
#define log_trace(format,...)     { if (LogLevel >= LOG_LEVEL_TRACE)   printk("~" format, ##__VA_ARGS__); }

#ifdef DEBUG
#define log_debug(format,...)     { if (LogLevel >= LOG_LEVEL_DEBUG)   printk("+" format, ##__VA_ARGS__); }
#else
#define log_debug(format,...)
#endif



/******************************************************************************
 *
 * Globals
 *
 *****************************************************************************/
extern unsigned int LogLevel;
extern unsigned int MsiMode;
extern unsigned int ShutdownMode;

extern const char   DriverVersionString[];
extern const char   *LogLevelTxt[];
extern const char   *IrqModeTxt[];
extern const char   *ModelTxt[];

extern void cs_xtrace(char *txt, void *data, int len);
extern int  cs_get_args(char *p_arg, const char *fmt, ...);

#endif
