MBK: slot 0 empty
MBK: slot 1 empty
MBK: slot 2 empty
MBK: slot 3 loaded AES key 32 bytes
KEY:
   0  ff002b66 564d706f  7a2a8b17 337b9fb8
  10  9ebc5998 a76e0286  fc3c72b3 c81c00ff
